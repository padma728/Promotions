﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelOrder
{
    class Program
    {
        static void Main(string[] args)
        {
            DataTable table = new DataTable();

            var counter = 0;
            using (var reader = new StreamReader(@"example1.csv"))
            {
                while (!reader.EndOfStream)
                {
                    counter++;
                    var line = reader.ReadLine();
                    if (counter == 1) //Assumtion: First row is column headers
                    {
                        foreach (var s in line.Split(','))
                        {
                            var dataColumn = new DataColumn(s);
                            table.Columns.Add(dataColumn);
                        }
                        //table.Columns.AddRange(line.Split(',').Select(s => new DataColumn(s)).ToArray());
                    }
                    else
                    {
                        var row = table.NewRow();
                        var values = line.Split(',');
                        int i = 0;
                        foreach (var value in values)
                        {
                            row[i++] = value;
                        }
                        table.Rows.Add(row);
                        Console.WriteLine(line);
                    }
                }
            }
            //Perform sort of the table based on argument
            table.DefaultView.Sort = args[0];
            var table2 = table.DefaultView.ToTable();
            using (var writer = new StreamWriter("example2.csv"))
            {
                foreach (DataRow row in table2.Rows)
                {
                    string commaSeperatedRow = string.Empty;
                    for (int i = 0; i < table.Columns.Count; i++)
                    {
                        if (i == 0)
                        {
                            commaSeperatedRow = row[i].ToString();
                        }
                        else
                        {
                            commaSeperatedRow = $"{commaSeperatedRow}, {row[i].ToString()}";
                        }
                    }
                    writer.WriteLine(commaSeperatedRow);
                }
            }

        }

    }
}
